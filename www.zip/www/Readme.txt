base de dados: 
		nome->goma
		user->root
		password->admin

server:
		XAMPP
